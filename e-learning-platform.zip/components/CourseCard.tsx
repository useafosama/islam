import React from 'react';
import type { Course } from '../types';

interface CourseCardProps {
  course: Course;
  onSelect: () => void;
  onCheckout: () => void;
}

const CourseCard: React.FC<CourseCardProps> = ({ course, onSelect, onCheckout }) => {
  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden flex flex-col h-full border border-gray-200 hover:shadow-xl transition-shadow duration-300">
      <div onClick={onSelect} className="cursor-pointer">
        <img className="w-full h-48 object-cover" src={course.thumbnail} alt={course.title} />
      </div>
      <div className="p-4 flex flex-col flex-grow">
        <div className="flex justify-between items-start mb-2">
            <span className="text-sm bg-purple-100 text-purple-700 font-semibold px-2 py-1 rounded">{course.subtitle}</span>
            {course.originalPrice && <span className="text-sm bg-green-100 text-green-700 font-semibold px-2 py-1 rounded">خصم</span>}
        </div>
        <h3 className="text-lg font-bold text-gray-800 mb-2 h-14" onClick={onSelect} >{course.title}</h3>
        <div className="text-gray-600 text-sm mb-4 space-y-1">
            <p>أستاذ: {course.instructor}</p>
            <p>عدد المحاضرات: {course.lecturesCount} محاضرات</p>
        </div>
        <div className="flex items-baseline text-gray-900 mt-auto">
          <span className="text-2xl font-extrabold tracking-tight">{course.price}</span>
          <span className="mr-1 text-sm font-semibold">جنيه</span>
          {course.originalPrice && (
            <span className="mr-2 text-sm text-gray-500 line-through">{course.originalPrice} جنيه</span>
          )}
        </div>
      </div>
      <div className="p-4 border-t border-gray-200 grid grid-cols-1 gap-2">
        <button 
          onClick={onSelect}
          className="w-full text-center py-2 px-4 border border-brand-red rounded-md text-sm font-medium text-brand-red bg-white hover:bg-red-50"
        >
          التفاصيل
        </button>
        <button 
          onClick={onCheckout}
          className="w-full text-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-brand-red hover:bg-brand-red-dark">
          الإشتراك في الكورس!
        </button>
      </div>
    </div>
  );
};

export default CourseCard;
