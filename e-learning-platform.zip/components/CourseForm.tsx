import React, { useState, useEffect } from 'react';
import type { Course } from '../types';

interface CourseFormProps {
  course: Course | null;
  onSave: (course: Course) => void;
  onCancel: () => void;
}

const CourseForm: React.FC<CourseFormProps> = ({ course, onSave, onCancel }) => {
    const [formData, setFormData] = useState<Omit<Course, 'id' | 'curriculum'> & {id?: number}>({
        title: '',
        subtitle: '',
        instructor: 'إسلام سعيد',
        price: 0,
        originalPrice: undefined,
        thumbnail: '',
        lecturesCount: 0,
        level: 'مبتدئ',
        category: '',
    });

    useEffect(() => {
        if (course) {
            setFormData(course);
        } else {
             setFormData({
                title: '',
                subtitle: '',
                instructor: 'إسلام سعيد',
                price: 0,
                originalPrice: undefined,
                thumbnail: '',
                lecturesCount: 0,
                level: 'مبتدئ',
                category: '',
            });
        }
    }, [course]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: name === 'price' || name === 'lecturesCount' || name === 'originalPrice' ? Number(value) || undefined : value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({ ...formData, id: course?.id ?? 0, curriculum: course?.curriculum || [] });
    };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">عنوان الكورس</label>
                <input type="text" name="title" id="title" value={formData.title} onChange={handleChange} required className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-brand-red focus:border-brand-red" />
            </div>
            <div>
                <label htmlFor="subtitle" className="block text-sm font-medium text-gray-700 mb-1">العنوان الفرعي (e.g., الصف الأول الثانوي)</label>
                <input type="text" name="subtitle" id="subtitle" value={formData.subtitle} onChange={handleChange} className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-brand-red focus:border-brand-red" />
            </div>
            <div>
                <label htmlFor="price" className="block text-sm font-medium text-gray-700 mb-1">السعر (جنيه)</label>
                <input type="number" name="price" id="price" value={formData.price} onChange={handleChange} required className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-brand-red focus:border-brand-red" />
            </div>
            <div>
                <label htmlFor="originalPrice" className="block text-sm font-medium text-gray-700 mb-1">السعر الأصلي (قبل الخصم)</label>
                <input type="number" name="originalPrice" id="originalPrice" value={formData.originalPrice || ''} onChange={handleChange} className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-brand-red focus:border-brand-red" />
            </div>
            <div>
                <label htmlFor="lecturesCount" className="block text-sm font-medium text-gray-700 mb-1">عدد المحاضرات</label>
                <input type="number" name="lecturesCount" id="lecturesCount" value={formData.lecturesCount} onChange={handleChange} required className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-brand-red focus:border-brand-red" />
            </div>
            <div>
                <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-1">الفئة</label>
                <input type="text" name="category" id="category" value={formData.category} onChange={handleChange} required className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-brand-red focus:border-brand-red" />
            </div>
             <div>
                <label htmlFor="thumbnail" className="block text-sm font-medium text-gray-700 mb-1">رابط الصورة المصغرة</label>
                <input type="text" name="thumbnail" id="thumbnail" value={formData.thumbnail} onChange={handleChange} className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-brand-red focus:border-brand-red" />
            </div>
        </div>
        <div className="flex justify-end gap-4 pt-4">
            <button type="button" onClick={onCancel} className="px-6 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50">
                إلغاء
            </button>
            <button type="submit" className="px-6 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-brand-red hover:bg-brand-red-dark">
                حفظ
            </button>
        </div>
    </form>
  );
};

export default CourseForm;
