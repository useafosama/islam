import React, { useState } from 'react';
import { courses as initialCourses } from '../data/mockData';
import type { Course } from '../types';
import CourseTable from './CourseTable';
import CourseForm from './CourseForm';
import BookOpenIcon from './icons/BookOpenIcon';
import UsersIcon from './icons/UsersIcon';
import CreditCardIcon from './icons/CreditCardIcon';
import PlusIcon from './icons/PlusIcon';


const AdminDashboard: React.FC = () => {
    const [courses, setCourses] = useState<Course[]>(initialCourses);
    const [view, setView] = useState<'table' | 'form'>('table');
    const [editingCourse, setEditingCourse] = useState<Course | null>(null);

    const handleAddNew = () => {
        setEditingCourse(null);
        setView('form');
    };

    const handleEdit = (course: Course) => {
        setEditingCourse(course);
        setView('form');
    };

    const handleDelete = (courseId: number) => {
        if(window.confirm('Are you sure you want to delete this course?')) {
            setCourses(courses.filter(c => c.id !== courseId));
        }
    };
    
    const handleSave = (course: Course) => {
        if (course.id && courses.some(c => c.id === course.id)) {
            setCourses(courses.map(c => c.id === course.id ? course : c));
        } else {
            // A real app would generate a unique ID on the backend
            const newCourse = { ...course, id: Date.now() };
            setCourses([...courses, newCourse]);
        }
        setView('table');
        setEditingCourse(null);
    };

    const handleCancel = () => {
        setView('table');
        setEditingCourse(null);
    };

  return (
    <div className="bg-gray-100 min-h-screen">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-6">لوحة التحكم</h1>
        
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            <div className="bg-white p-6 rounded-lg shadow flex items-center justify-between">
                <div>
                    <p className="text-sm font-medium text-gray-500">إجمالي الكورسات</p>
                    <p className="text-2xl font-bold text-gray-800">{courses.length}</p>
                </div>
                <div className="bg-blue-100 text-blue-600 p-3 rounded-full">
                    <BookOpenIcon className="w-6 h-6" />
                </div>
            </div>
             <div className="bg-white p-6 rounded-lg shadow flex items-center justify-between">
                <div>
                    <p className="text-sm font-medium text-gray-500">إجمالي الطلاب</p>
                    <p className="text-2xl font-bold text-gray-800">1,250</p>
                </div>
                <div className="bg-green-100 text-green-600 p-3 rounded-full">
                    <UsersIcon className="w-6 h-6" />
                </div>
            </div>
             <div className="bg-white p-6 rounded-lg shadow flex items-center justify-between">
                <div>
                    <p className="text-sm font-medium text-gray-500">إجمالي المبيعات</p>
                    <p className="text-2xl font-bold text-gray-800">150,000 جنيه</p>
                </div>
                <div className="bg-yellow-100 text-yellow-600 p-3 rounded-full">
                    <CreditCardIcon className="w-6 h-6" />
                </div>
            </div>
        </div>

        {/* Main Content */}
        <div className="bg-white p-6 rounded-lg shadow">
            {view === 'table' && (
                <div>
                    <div className="flex justify-between items-center mb-4">
                        <h2 className="text-xl font-semibold text-gray-700">إدارة الكورسات</h2>
                        <button 
                            onClick={handleAddNew}
                            className="flex items-center gap-2 bg-brand-red text-white font-bold py-2 px-4 rounded-lg hover:bg-brand-red-dark transition duration-300">
                            <PlusIcon className="w-5 h-5" />
                            إضافة كورس جديد
                        </button>
                    </div>
                    <CourseTable courses={courses} onEdit={handleEdit} onDelete={handleDelete} />
                </div>
            )}

            {view === 'form' && (
                <div>
                    <h2 className="text-xl font-semibold text-gray-700 mb-4">
                        {editingCourse ? 'تعديل الكورس' : 'إضافة كورس جديد'}
                    </h2>
                    <CourseForm course={editingCourse} onSave={handleSave} onCancel={handleCancel} />
                </div>
            )}
        </div>

      </div>
    </div>
  );
};

export default AdminDashboard;
