import React from 'react';

const Hero: React.FC = () => {
  return (
    <div className="bg-brand-red text-white overflow-hidden">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center pt-10 md:pt-0">
          {/* Text Content */}
          <div className="md:w-1/2 text-center md:text-right mb-10 md:mb-0">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black leading-tight mb-4">
              منصتك الأولى لإتقان اللغة العربية بأسلوب شيق ومبتكر
            </h1>
            <p className="text-lg lg:text-xl mb-8 max-w-xl mx-auto md:mx-0">
              أهلاً بك في عالم اللغة العربية، حيث نجعل من تعلمها رحلة ممتعة ومثمرة. شروحات وافية، تطبيقات عملية، ومتابعة مستمرة لتحقيق التفوق.
            </p>
            <a href="#" className="inline-block bg-white text-brand-red font-bold text-lg px-10 py-3 rounded-lg shadow-lg hover:bg-gray-100 transition duration-300">
              اشترك دلوقتي!
            </a>
          </div>

          {/* Image Content */}
          <div className="md:w-1/2 relative flex justify-center md:justify-start">
             <div className="relative w-full max-w-md lg:max-w-lg">
                <div className="absolute -top-10 -left-10 w-32 h-32 bg-white/20 rounded-full filter blur-xl opacity-50 animate-pulse"></div>
                <div className="absolute -bottom-10 -right-10 w-48 h-48 bg-white/20 rounded-full filter blur-2xl opacity-50 animate-pulse delay-500"></div>
                <img 
                    src="https://picsum.photos/seed/arabic-teacher/500/600" 
                    alt="مستر إسلام سعيد" 
                    className="relative z-10 w-full h-auto object-cover"
                    style={{ maxHeight: '600px' }}
                />
            </div>
          </div>
        </div>
        
        {/* Stats Section */}
        <div className="flex justify-center md:justify-start gap-x-12 lg:gap-x-20 pb-10 pt-5">
            <div className="text-center">
                <p className="text-4xl lg:text-5xl font-black text-brand-yellow">1.0M+</p>
                <p className="text-lg">متابعين على الفيسبوك</p>
            </div>
            <div className="text-center">
                <p className="text-4xl lg:text-5xl font-black text-brand-yellow">2.0M+</p>
                <p className="text-lg">متابعين على اليوتيوب</p>
            </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;