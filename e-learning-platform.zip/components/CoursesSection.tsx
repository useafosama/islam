import React, { useRef } from 'react';
import CourseCard from './CourseCard';
import type { Course } from '../types';
import ChevronLeftIcon from './icons/ChevronLeftIcon';
import ChevronRightIcon from './icons/ChevronRightIcon';

interface CoursesSectionProps {
  title: string;
  courses: Course[];
  onCourseSelect: (course: Course) => void;
  onStartCheckout: (course: Course) => void;
}

const CoursesSection: React.FC<CoursesSectionProps> = ({ title, courses, onCourseSelect, onStartCheckout }) => {
  const scrollContainer = useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollContainer.current) {
      const scrollAmount = scrollContainer.current.offsetWidth * 0.8;
      scrollContainer.current.scrollBy({
        left: direction === 'right' ? -scrollAmount : scrollAmount,
        behavior: 'smooth',
      });
    }
  };

  return (
    <section className="py-12 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-3xl font-bold text-gray-800">{title}</h2>
          <div className="flex items-center space-x-2 space-x-reverse">
            <button onClick={() => scroll('left')} className="p-2 rounded-full bg-gray-200 hover:bg-gray-300 text-gray-600 transition duration-300">
              <ChevronRightIcon />
            </button>
            <button onClick={() => scroll('right')} className="p-2 rounded-full bg-gray-200 hover:bg-gray-300 text-gray-600 transition duration-300">
              <ChevronLeftIcon />
            </button>
          </div>
        </div>
        <div 
          ref={scrollContainer}
          className="flex overflow-x-auto space-x-6 space-x-reverse pb-4"
          style={{ scrollSnapType: 'x mandatory' }}
        >
          {courses.map((course) => (
            <div key={course.id} style={{ scrollSnapAlign: 'start' }} className="flex-shrink-0 w-full sm:w-1/2 md:w-1/3 lg:w-1/4">
              <CourseCard 
                course={course} 
                onSelect={() => onCourseSelect(course)} 
                onCheckout={() => onStartCheckout(course)} 
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CoursesSection;
