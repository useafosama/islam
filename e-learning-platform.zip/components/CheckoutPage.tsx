import React, { useState } from 'react';
import type { Course } from '../types';
import ClipboardIcon from './icons/ClipboardIcon';
import WhatsAppIcon from './icons/WhatsAppIcon';

interface CheckoutPageProps {
  course: Course;
  onBack: () => void;
}

const CheckoutPage: React.FC<CheckoutPageProps> = ({ course, onBack }) => {
  const [copyButtonText, setCopyButtonText] = useState('نسخ الرقم');
  const phoneNumber = '01067890109';
  const whatsAppNumber = '201067890109'; // With country code for wa.me link

  const handleCopy = () => {
    navigator.clipboard.writeText(phoneNumber).then(() => {
      setCopyButtonText('تم النسخ!');
      setTimeout(() => {
        setCopyButtonText('نسخ الرقم');
      }, 2000);
    }).catch(err => {
      console.error('Failed to copy: ', err);
    });
  };

  const message = `أهلاً، أرغب في تأكيد دفع كورس:\n\nاسم الكورس: ${course.title}\nالسعر: ${course.price} جنيه\n\nلقد قمت بالدفع، برجاء مراجعة الصورة المرفقة.`;
  const encodedMessage = encodeURIComponent(message);
  const whatsAppLink = `https://wa.me/${whatsAppNumber}?text=${encodedMessage}`;

  return (
    <div className="py-12 px-4 sm:px-6 lg:px-8 flex items-center justify-center">
      <div className="max-w-2xl w-full bg-white rounded-2xl shadow-xl p-8 border border-gray-200">
        <button onClick={onBack} className="text-brand-red hover:underline mb-6">&larr; العودة</button>
        <div className="text-center">
            <h1 className="text-3xl font-bold text-gray-900 mb-4">إتمام عملية الدفع</h1>
            <p className="text-gray-600 mb-8">
                لشراء الكورس، يرجى اتباع الخطوات التالية لإتمام عملية الدفع اليدوي.
            </p>
        </div>
        
        <div className="bg-gray-50 rounded-lg p-6 mb-6 border border-dashed">
            <h2 className="text-xl font-bold text-gray-800 mb-2">{course.title}</h2>
            <div className="flex items-baseline text-gray-900">
                <span className="text-3xl font-extrabold tracking-tight">{course.price}</span>
                <span className="mr-1.5 text-lg font-semibold">جنيه مصري</span>
            </div>
        </div>

        <div className="space-y-6">
            <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-2">1. تحويل المبلغ</h3>
                <p className="text-gray-600 mb-4">
                    برجاء تحويل المبلغ على رقم فودافون كاش أو انستا باي التالي:
                </p>
                <div className="flex flex-col sm:flex-row gap-3">
                    <div className="flex-grow text-center ltr-text bg-gray-100 border rounded-md px-4 py-3 text-2xl font-mono tracking-widest text-gray-800">
                        {phoneNumber}
                    </div>
                    <button 
                        onClick={handleCopy}
                        className="flex items-center justify-center gap-2 w-full sm:w-auto whitespace-nowrap px-6 py-3 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 transition-colors duration-200"
                    >
                        <ClipboardIcon className="w-5 h-5" />
                        {copyButtonText}
                    </button>
                </div>
            </div>

            <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-2">2. تأكيد الدفع</h3>
                <p className="text-gray-600 mb-4">
                    بعد التحويل، اضغط على الزر التالي لإرسال صورة من إيصال الدفع (سكرين شوت) على واتساب لتأكيد اشتراكك.
                </p>
                 <a 
                    href={whatsAppLink} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="w-full flex items-center justify-center gap-3 text-center py-4 px-6 border border-transparent rounded-md shadow-sm text-lg font-medium text-white bg-green-500 hover:bg-green-600 transition-colors duration-200"
                >
                    <WhatsAppIcon className="w-6 h-6" />
                    إرسال تأكيد الدفع على واتساب
                </a>
            </div>
        </div>
      </div>
    </div>
  );
};

export default CheckoutPage;
