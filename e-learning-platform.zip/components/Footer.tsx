import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-800 text-white">
      <div className="container mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="xl:grid xl:grid-cols-3 xl:gap-8">
          <div className="space-y-8 xl:col-span-1">
             <span className="text-2xl font-black text-white tracking-wider">عمو - مستر إسلام سعيد</span>
            <p className="text-gray-400 text-base">
                منصة تعليمية متكاملة للغة العربية، تهدف إلى تقديم شرح مبسط ومتابعة فعالة للطلاب.
            </p>
            {/* Social media can be added here */}
          </div>
          <div className="mt-12 grid grid-cols-2 gap-8 xl:mt-0 xl:col-span-2">
            <div className="md:grid md:grid-cols-2 md:gap-8">
              <div>
                <h3 className="text-sm font-semibold text-gray-200 tracking-wider uppercase">روابط سريعة</h3>
                <ul className="mt-4 space-y-4">
                  <li><a href="#" className="text-base text-gray-400 hover:text-white">الرئيسية</a></li>
                  <li><a href="#" className="text-base text-gray-400 hover:text-white">جميع الكورسات</a></li>
                  <li><a href="#" className="text-base text-gray-400 hover:text-white">سياسة الخصوصية</a></li>
                </ul>
              </div>
              <div className="mt-12 md:mt-0">
                <h3 className="text-sm font-semibold text-gray-200 tracking-wider uppercase">الدعم</h3>
                <ul className="mt-4 space-y-4">
                  <li><a href="#" className="text-base text-gray-400 hover:text-white">تواصل معنا</a></li>
                  <li><a href="#" className="text-base text-gray-400 hover:text-white">الأسئلة الشائعة</a></li>
                </ul>
              </div>
            </div>
            <div className="md:grid md:grid-cols-1 md:gap-8">
              <div>
                <h3 className="text-sm font-semibold text-gray-200 tracking-wider uppercase">اشترك في النشرة البريدية</h3>
                <p className="text-gray-400 mt-4">احصل على آخر التحديثات والعروض مباشرة في بريدك الإلكتروني.</p>
                <form className="mt-4 sm:flex sm:max-w-md">
                    <label htmlFor="email-address" className="sr-only">Email address</label>
                    <input type="email" name="email-address" id="email-address" autoComplete="email" required className="appearance-none min-w-0 w-full bg-white border border-transparent rounded-md py-2 px-4 text-base text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-white focus:border-white focus:placeholder-gray-400" placeholder="أدخل بريدك الإلكتروني" />
                    <div className="mt-3 rounded-md sm:mt-0 sm:mr-3 sm:flex-shrink-0">
                        <button type="submit" className="w-full bg-brand-red flex items-center justify-center border border-transparent rounded-md py-2 px-4 text-base font-medium text-white hover:bg-brand-red-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-brand-red">
                            إشتراك
                        </button>
                    </div>
                </form>
              </div>
            </div>
          </div>
        </div>
        <div className="mt-12 border-t border-gray-700 pt-8">
          <p className="text-base text-gray-400 xl:text-center">&copy; 2024 منصة عمو - مستر إسلام سعيد. كل الحقوق محفوظة.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;