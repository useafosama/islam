import React from 'react';
import type { Course } from '../types';
import PencilIcon from './icons/PencilIcon';
import TrashIcon from './icons/TrashIcon';

interface CourseTableProps {
  courses: Course[];
  onEdit: (course: Course) => void;
  onDelete: (courseId: number) => void;
}

const CourseTable: React.FC<CourseTableProps> = ({ courses, onEdit, onDelete }) => {
  return (
    <div className="overflow-x-auto">
      <table className="min-w-full bg-white">
        <thead className="bg-gray-100">
          <tr>
            <th className="text-right py-3 px-4 font-semibold text-sm text-gray-600 uppercase tracking-wider">العنوان</th>
            <th className="text-right py-3 px-4 font-semibold text-sm text-gray-600 uppercase tracking-wider">السعر</th>
            <th className="text-right py-3 px-4 font-semibold text-sm text-gray-600 uppercase tracking-wider">عدد المحاضرات</th>
            <th className="text-right py-3 px-4 font-semibold text-sm text-gray-600 uppercase tracking-wider">الفئة</th>
            <th className="py-3 px-4"></th>
          </tr>
        </thead>
        <tbody className="text-gray-700">
          {courses.map((course) => (
            <tr key={course.id} className="border-b border-gray-200 hover:bg-gray-50">
              <td className="py-3 px-4">{course.title}</td>
              <td className="py-3 px-4">{course.price} جنيه</td>
              <td className="py-3 px-4">{course.lecturesCount}</td>
              <td className="py-3 px-4">{course.category}</td>
              <td className="py-3 px-4">
                <div className="flex items-center justify-end space-x-2 space-x-reverse">
                  <button onClick={() => onEdit(course)} className="text-blue-500 hover:text-blue-700 p-2 rounded-full hover:bg-blue-100">
                    <PencilIcon className="w-5 h-5" />
                  </button>
                  <button onClick={() => onDelete(course.id)} className="text-red-500 hover:text-red-700 p-2 rounded-full hover:bg-red-100">
                    <TrashIcon className="w-5 h-5" />
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default CourseTable;
