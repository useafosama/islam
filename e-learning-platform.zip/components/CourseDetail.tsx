import React, { useState } from 'react';
import type { Course, Module, Lesson } from '../types';
import ChevronDownIcon from './icons/ChevronDownIcon';
import CheckCircleIcon from './icons/CheckCircleIcon';
import PlayCircleIcon from './icons/PlayCircleIcon';

const ModuleItem: React.FC<{ module: Module, totalLessons: number, completedLessons: number }> = ({ module, totalLessons, completedLessons }) => {
  const [isOpen, setIsOpen] = useState(true);

  return (
    <div className="border rounded-lg overflow-hidden">
      <button 
        onClick={() => setIsOpen(!isOpen)} 
        className="w-full flex justify-between items-center p-4 bg-gray-100 hover:bg-gray-200 transition"
      >
        <div className="text-right">
          <h3 className="font-bold text-gray-800">{module.title}</h3>
          <span className="text-sm text-gray-500">{completedLessons}/{totalLessons}</span>
        </div>
        <ChevronDownIcon className={`w-6 h-6 transform transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && (
        <div className="bg-white">
          {module.lessons.map((lesson, index) => (
            <div key={lesson.id} className={`flex items-center justify-between p-4 ${index < module.lessons.length - 1 ? 'border-b' : ''}`}>
              <div className="flex items-center">
                <PlayCircleIcon className="w-6 h-6 text-gray-400 mr-3" />
                <span className="text-gray-700">{lesson.title}</span>
                {lesson.isPreviewable && <span className="mr-2 text-xs bg-blue-100 text-blue-800 px-2 py-0.5 rounded-full">معاينة</span>}
              </div>
              {lesson.isCompleted ? <CheckCircleIcon className="w-6 h-6 text-green-500" /> : <div className="w-6 h-6"></div>}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

interface CourseDetailProps {
  course: Course;
  onBack: () => void;
  onStartCheckout: (course: Course) => void;
}

const CourseDetail: React.FC<CourseDetailProps> = ({ course, onBack, onStartCheckout }) => {
    const totalLessons = course.curriculum.reduce((acc, module) => acc + module.lessons.length, 0);
    const completedLessons = course.curriculum.reduce((acc, module) => acc + module.lessons.filter(l => l.isCompleted).length, 0);

    return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <button onClick={onBack} className="text-brand-red hover:underline mb-6">&larr; العودة إلى الكورسات</button>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Right column for curriculum */}
        <div className="lg:col-span-2 order-2 lg:order-1">
          <h2 className="text-2xl font-bold mb-4">محتوى الكورس</h2>
          <div className="space-y-4">
            {course.curriculum.map(module => (
              <ModuleItem 
                key={module.id} 
                module={module} 
                totalLessons={module.lessons.length}
                completedLessons={module.lessons.filter(l => l.isCompleted).length}
              />
            ))}
          </div>
        </div>

        {/* Left column for course info */}
        <div className="lg:col-span-1 order-1 lg:order-2">
            <div className="sticky top-24">
                <div className="bg-white rounded-lg shadow-lg overflow-hidden border border-gray-200">
                    <div className="bg-gray-800 aspect-video flex items-center justify-center">
                        <PlayCircleIcon className="w-20 h-20 text-white opacity-70"/>
                    </div>
                     <div className="p-6">
                        <h1 className="text-2xl font-bold text-gray-900 mb-4">{course.title}</h1>
                         <div className="flex items-baseline text-gray-900 mb-4">
                            <span className="text-3xl font-extrabold tracking-tight">{course.price}</span>
                            <span className="mr-1 text-lg font-semibold">جنيه</span>
                            {course.originalPrice && (
                                <span className="mr-3 text-lg text-gray-500 line-through">{course.originalPrice} جنيه</span>
                            )}
                        </div>
                        <button 
                            onClick={() => onStartCheckout(course)}
                            className="w-full bg-brand-red text-white font-bold py-3 px-4 rounded-lg hover:bg-brand-red-dark transition duration-300 mb-4">
                            اشترك الآن!
                        </button>
                        <div className="text-sm text-gray-600">
                            <h4 className="font-bold mb-2">هذا الكورس يتضمن:</h4>
                            <ul className="space-y-2">
                                <li className="flex items-center"><CheckCircleIcon className="w-5 h-5 text-green-500 ml-2" /> {totalLessons} محاضرة</li>
                                <li className="flex items-center"><CheckCircleIcon className="w-5 h-5 text-green-500 ml-2" /> وصول مدى الحياة</li>
                                <li className="flex items-center"><CheckCircleIcon className="w-5 h-5 text-green-500 ml-2" /> شهادة إتمام</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default CourseDetail;
