import type { Course } from '../types';

export const courses: Course[] = [
  {
    id: 1,
    title: 'كورس النحو الشامل للمرحلة الثانوية',
    subtitle: 'الصف الثالث الثانوي',
    instructor: 'إسلام سعيد',
    price: 600,
    originalPrice: 750,
    thumbnail: 'https://picsum.photos/seed/nahw/400/300',
    lecturesCount: 45,
    level: 'متقدم',
    category: 'النحو',
    curriculum: [
      {
        id: 'm1-1',
        title: 'الوحدة الأولى: النطق والإملاء',
        lessons: [
          { id: 'l1-1-1', title: 'همزة القطع وألف الوصل', type: 'lecture', isCompleted: true, isPreviewable: true },
          { id: 'l1-1-2', title: 'اللام الشمسية والقمرية', type: 'lecture', isCompleted: true, isPreviewable: false },
          { id: 'l1-1-3', title: 'التاء المربوطة والمفتوحة والهاء', type: 'lecture', isCompleted: false, isPreviewable: false },
          { id: 'l1-1-4', title: 'اختبار الوحدة الأولى', type: 'quiz', isCompleted: false, isPreviewable: false },
        ],
      },
      {
        id: 'm1-2',
        title: 'الوحدة الثانية: الأبنية',
        lessons: [
          { id: 'l1-2-1', title: 'المشتقات العاملة', type: 'lecture', isCompleted: false, isPreviewable: false },
          { id: 'l1-2-2', title: 'اسم الفاعل وصيغ المبالغة', type: 'lecture', isCompleted: false, isPreviewable: false },
          { id: 'l1-2-3', title: 'اسم المفعول', type: 'assignment', isCompleted: false, isPreviewable: false },
        ],
      },
    ],
  },
  {
    id: 2,
    title: 'كورس البلاغة والنصوص',
    subtitle: 'الصف الثاني الثانوي',
    instructor: 'إسلام سعيد',
    price: 450,
    thumbnail: 'https://picsum.photos/seed/balagha/400/300',
    lecturesCount: 30,
    level: 'متوسط',
    category: 'البلاغة',
    curriculum: [
       {
        id: 'm2-1',
        title: 'علم البيان',
        lessons: [
          { id: 'l2-1-1', title: 'التشبيه وأركانه', type: 'lecture', isCompleted: true, isPreviewable: true },
          { id: 'l2-1-2', title: 'الاستعارة وأنواعها', type: 'lecture', isCompleted: false, isPreviewable: false },
          { id: 'l2-1-3', title: 'الكناية والمجاز المرسل', type: 'quiz', isCompleted: false, isPreviewable: false },
        ],
      },
    ],
  },
  {
    id: 3,
    title: 'تأسيس في القراءة المتحررة',
    subtitle: 'جميع المراحل',
    instructor: 'إسلام سعيد',
    price: 300,
    originalPrice: 400,
    thumbnail: 'https://picsum.photos/seed/reading/400/300',
    lecturesCount: 20,
    level: 'مبتدئ',
    category: 'القراءة',
    curriculum: [],
  },
  {
    id: 4,
    title: 'المراجعة النهائية في اللغة العربية',
    subtitle: 'الصف الثالث الثانوي',
    instructor: 'إسلام سعيد',
    price: 800,
    thumbnail: 'https://picsum.photos/seed/final-review/400/300',
    lecturesCount: 60,
    level: 'متقدم',
    category: 'مراجعة',
    curriculum: [],
  },
];
